#!/bin/bash

# Global Strategic Technologies - PNG Generation Script
# Converts SVG logos to PNG at various sizes for different use cases

echo "🎨 GST Logo PNG Generation Script"
echo "=================================="
echo ""

# Check if Inkscape is installed
if ! command -v inkscape &> /dev/null; then
    echo "❌ Error: Inkscape is not installed."
    echo ""
    echo "Please install Inkscape:"
    echo "  macOS:   brew install inkscape"
    echo "  Ubuntu:  sudo apt install inkscape"
    echo "  Windows: Download from inkscape.org"
    echo ""
    echo "Or use online converter: https://cloudconvert.com/svg-to-png"
    exit 1
fi

echo "✅ Inkscape found!"
echo ""

# Create directories
mkdir -p png/{horizontal,stacked,icon,favicon,social,email}

echo "📦 Generating PNG files..."
echo ""

# === HORIZONTAL LOGOS ===
echo "1/8 Converting horizontal logos..."

# Full name horizontal - various sizes
inkscape --export-type=png --export-width=1400 svg/gst-logo-full-horizontal-color-transparent.svg -o png/horizontal/gst-logo-full-1400w.png
inkscape --export-type=png --export-width=1000 svg/gst-logo-full-horizontal-color-transparent.svg -o png/horizontal/gst-logo-full-1000w.png
inkscape --export-type=png --export-width=700 svg/gst-logo-full-horizontal-color-transparent.svg -o png/horizontal/gst-logo-full-700w.png

# GS Tech horizontal
inkscape --export-type=png --export-width=700 svg/gst-logo-gstech-horizontal-color-transparent.svg -o png/horizontal/gst-logo-gstech-700w.png
inkscape --export-type=png --export-width=500 svg/gst-logo-gstech-horizontal-color-transparent.svg -o png/horizontal/gst-logo-gstech-500w.png

# GST compact horizontal
inkscape --export-type=png --export-width=520 svg/gst-logo-gst-horizontal-color-transparent.svg -o png/horizontal/gst-logo-gst-520w.png
inkscape --export-type=png --export-width=350 svg/gst-logo-gst-horizontal-color-transparent.svg -o png/horizontal/gst-logo-gst-350w.png

echo "   ✓ Horizontal logos complete"

# === STACKED LOGOS ===
echo "2/8 Converting stacked logos..."

# Full name stacked
inkscape --export-type=png --export-width=800 --export-height=800 svg/gst-logo-full-stacked-color-transparent.svg -o png/stacked/gst-logo-full-stacked-800.png
inkscape --export-type=png --export-width=400 --export-height=400 svg/gst-logo-full-stacked-color-transparent.svg -o png/stacked/gst-logo-full-stacked-400.png

# GS Tech stacked
inkscape --export-type=png --export-width=600 --export-height=600 svg/gst-logo-gstech-stacked-color-transparent.svg -o png/stacked/gst-logo-gstech-stacked-600.png
inkscape --export-type=png --export-width=300 --export-height=300 svg/gst-logo-gstech-stacked-color-transparent.svg -o png/stacked/gst-logo-gstech-stacked-300.png

echo "   ✓ Stacked logos complete"

# === ICON VERSIONS ===
echo "3/8 Converting icon versions..."

inkscape --export-type=png --export-width=512 --export-height=512 svg/gst-logo-icon-color-transparent.svg -o png/icon/gst-icon-512.png
inkscape --export-type=png --export-width=256 --export-height=256 svg/gst-logo-icon-color-transparent.svg -o png/icon/gst-icon-256.png
inkscape --export-type=png --export-width=128 --export-height=128 svg/gst-logo-icon-color-transparent.svg -o png/icon/gst-icon-128.png

echo "   ✓ Icon versions complete"

# === FAVICONS ===
echo "4/8 Converting favicons..."

inkscape --export-type=png --export-width=16 --export-height=16 favicon/favicon.svg -o png/favicon/favicon-16x16.png
inkscape --export-type=png --export-width=32 --export-height=32 favicon/favicon.svg -o png/favicon/favicon-32x32.png
inkscape --export-type=png --export-width=64 --export-height=64 favicon/favicon.svg -o png/favicon/favicon-64x64.png

echo "   ✓ Favicons complete"

# === APPLE TOUCH ICONS ===
echo "5/8 Converting Apple touch icons..."

inkscape --export-type=png --export-width=180 --export-height=180 svg/gst-logo-icon-color-transparent.svg -o png/favicon/apple-touch-icon.png
inkscape --export-type=png --export-width=152 --export-height=152 svg/gst-logo-icon-color-transparent.svg -o png/favicon/apple-touch-icon-152x152.png
inkscape --export-type=png --export-width=120 --export-height=120 svg/gst-logo-icon-color-transparent.svg -o png/favicon/apple-touch-icon-120x120.png

echo "   ✓ Apple touch icons complete"

# === ANDROID CHROME ===
echo "6/8 Converting Android Chrome icons..."

inkscape --export-type=png --export-width=192 --export-height=192 svg/gst-logo-icon-color-transparent.svg -o png/favicon/android-chrome-192x192.png
inkscape --export-type=png --export-width=512 --export-height=512 svg/gst-logo-icon-color-transparent.svg -o png/favicon/android-chrome-512x512.png

echo "   ✓ Android Chrome icons complete"

# === SOCIAL MEDIA ===
echo "7/8 Converting social media images..."

# LinkedIn profile (square)
inkscape --export-type=png --export-width=400 --export-height=400 svg/gst-logo-gstech-stacked-color-transparent.svg -o png/social/linkedin-profile-400x400.png

# Open Graph (1200x630)
# Note: This requires a custom composition - recommend doing manually
echo "   ⚠️  Open Graph (1200x630) - Create manually with full context"

# Twitter card (1200x675)
echo "   ⚠️  Twitter card (1200x675) - Create manually with full context"

echo "   ✓ Social media base images complete"

# === EMAIL SIGNATURE ===
echo "8/8 Converting email signature..."

# GS Tech for email (2x resolution for retina)
inkscape --export-type=png --export-width=560 --export-height=112 svg/gst-logo-gstech-horizontal-color-transparent.svg -o png/email/gst-logo-gstech-email-2x.png
inkscape --export-type=png --export-width=280 --export-height=56 svg/gst-logo-gstech-horizontal-color-transparent.svg -o png/email/gst-logo-gstech-email-1x.png

echo "   ✓ Email signature complete"

echo ""
echo "🎉 PNG Generation Complete!"
echo ""
echo "Files created in png/ subdirectories:"
echo "  • Horizontal logos: png/horizontal/"
echo "  • Stacked logos: png/stacked/"
echo "  • Icon versions: png/icon/"
echo "  • Favicons: png/favicon/"
echo "  • Social media: png/social/"
echo "  • Email signature: png/email/"
echo ""
echo "📋 Next steps:"
echo "  1. Copy all files to your website's /public/images/logo/ directory"
echo "  2. Generate favicon.ico: https://www.favicon-generator.org/"
echo "  3. Create custom Open Graph images (1200x630)"
echo "  4. Create custom Twitter card images (1200x675)"
echo "  5. Follow IMPLEMENTATION_GUIDE.md for website integration"
echo ""
echo "✨ Your logo system is ready!"
